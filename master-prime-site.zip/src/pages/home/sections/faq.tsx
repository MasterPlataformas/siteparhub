import { MessageCircle } from "lucide-react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/lib/site";

import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";
import { FAQ_ITEMS } from "../data";

const Faq = () => (
  <section id="faq" className="bg-gradient-warm py-16 lg:py-24">
    <Container size="narrow">
      <div className="lg:grid lg:grid-cols-12 lg:gap-12">
        <div className="lg:col-span-4">
          <SectionHeading
            eyebrow="Perguntas frequentes"
            title="Tire suas dúvidas sobre consórcio"
            description="Reunimos as perguntas que mais recebemos no atendimento. Se ficar qualquer dúvida, fale com um especialista."
          />
          <Reveal delay={120} className="mt-8 hidden lg:block">
            <Button asChild variant="whatsapp" size="xl">
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
                <MessageCircle aria-hidden="true" />
                Falar no WhatsApp
              </a>
            </Button>
          </Reveal>
        </div>

        <div className="mt-10 lg:col-span-8 lg:mt-0">
          <Reveal>
            <Accordion
              type="single"
              collapsible
              className="overflow-hidden rounded-xl border border-border bg-card px-5 shadow-sm lg:px-6"
            >
              {FAQ_ITEMS.map((item, index) => (
                <AccordionItem
                  key={item.question}
                  value={`faq-${index}`}
                  className="border-border last:border-b-0"
                >
                  <AccordionTrigger className="py-5 text-left text-base font-semibold text-card-foreground hover:text-primary hover:no-underline">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="max-w-[62ch] pr-8 text-sm leading-relaxed text-muted-foreground">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Reveal>

          <Reveal delay={120} className="mt-6 lg:hidden">
            <Button asChild variant="whatsapp" size="xl" className="w-full">
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
                <MessageCircle aria-hidden="true" />
                Falar no WhatsApp
              </a>
            </Button>
          </Reveal>
        </div>
      </div>
    </Container>
  </section>
);

export default Faq;
