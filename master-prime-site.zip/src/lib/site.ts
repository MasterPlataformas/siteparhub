/**
 * Dados fixos do site da Master Prime Consórcios.
 * Fonte: canais oficiais da empresa.
 */

export const CONTACT = {
  whatsappDisplay: "+55 (11) 97378-3200",
  whatsappNumber: "5511973783200",
  phoneDisplay: "(11) 4318-3734",
  phoneHref: "+551143183734",
  instagramHandle: "@masterprime.oficial",
  instagramUrl: "https://www.instagram.com/masterprime.oficial/",
  addressLine: "Salas 720 e 721",
  city: "São Caetano do Sul - SP",
  cnpj: "28.697.263/0001-10",
} as const;

export const DEFAULT_WHATSAPP_MESSAGE =
  "Olá! Vim pelo site da Master Prime e gostaria de uma simulação de consórcio.";

/** Monta um link do WhatsApp já com a mensagem codificada. */
export function whatsappLink(message: string = DEFAULT_WHATSAPP_MESSAGE): string {
  return `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const NAV_LINKS = [
  { id: "inicio", label: "Início" },
  { id: "modalidades", label: "Modalidades" },
  { id: "como-funciona", label: "Como funciona" },
  { id: "nosso-espaco", label: "Nosso espaço" },
  { id: "faq", label: "Dúvidas" },
] as const;

export const MODALITY_VALUES = ["Imóveis", "Veículos", "Motos", "Serviços"] as const;

export type ModalityValue = (typeof MODALITY_VALUES)[number];

/** Rola até uma seção respeitando o scroll-margin-top definido no CSS. */
export function scrollToSection(id: string): void {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}
