import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

type ContainerProps = {
  children: ReactNode;
  className?: string;
  size?: "default" | "narrow" | "form";
};

const SIZE_CLASS: Record<NonNullable<ContainerProps["size"]>, string> = {
  default: "max-w-[1280px]",
  narrow: "max-w-[1120px]",
  form: "max-w-[720px]",
};

const Container = ({ children, className, size = "default" }: ContainerProps) => (
  <div className={cn("mx-auto w-full px-5 lg:px-8", SIZE_CLASS[size], className)}>{children}</div>
);

export default Container;
