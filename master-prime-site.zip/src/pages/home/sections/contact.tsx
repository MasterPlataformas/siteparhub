import { Instagram, MapPin, MessageCircle, Phone } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import { CONTACT, whatsappLink } from "@/lib/site";

import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";

type ContactCard = {
  icon: LucideIcon;
  label: string;
  value: string;
  detail: string;
  href: string;
  external?: boolean;
};

const CONTACT_CARDS: ContactCard[] = [
  {
    icon: MessageCircle,
    label: "WhatsApp",
    value: CONTACT.whatsappDisplay,
    detail: "Resposta rápida com um especialista",
    href: whatsappLink(),
    external: true,
  },
  {
    icon: Phone,
    label: "SAC",
    value: CONTACT.phoneDisplay,
    detail: "Atendimento de segunda a sexta",
    href: `tel:${CONTACT.phoneHref}`,
  },
  {
    icon: MapPin,
    label: "Escritório",
    value: CONTACT.addressLine,
    detail: CONTACT.city,
    href: "#nosso-espaco",
  },
  {
    icon: Instagram,
    label: "Instagram",
    value: CONTACT.instagramHandle,
    detail: "Conquistas e novidades",
    href: CONTACT.instagramUrl,
    external: true,
  },
];

const Contact = () => (
  <section id="contato" className="surface-navy py-16 lg:py-24">
    <Container>
      <SectionHeading
        tone="light"
        eyebrow="Contato"
        title="Fale com um especialista da Master Prime"
        description="Conte o seu objetivo e receba uma simulação personalizada, com orientação para escolher o plano ideal e parcelas compatíveis com o seu momento."
      />

      <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {CONTACT_CARDS.map((card, index) => (
          <li key={card.label}>
            <Reveal delay={index * 70} className="h-full">
              <a
                href={card.href}
                {...(card.external
                  ? { target: "_blank", rel: "noopener noreferrer" }
                  : {})}
                className="flex h-full flex-col gap-4 rounded-xl border border-surface-foreground/12 bg-surface-foreground/[0.05] p-5 transition-colors hover:border-brand-amber/40 hover:bg-surface-foreground/[0.09] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                aria-label={`${card.label}: ${card.value}${card.external ? " (abre em nova aba)" : ""}`}
              >
                <card.icon className="h-5 w-5 text-brand-amber" aria-hidden="true" />
                <div>
                  <p className="eyebrow text-surface-muted">{card.label}</p>
                  <p className="mt-2 font-display text-base font-bold text-surface-foreground">
                    {card.value}
                  </p>
                  <p className="mt-1 text-xs text-surface-muted">{card.detail}</p>
                </div>
              </a>
            </Reveal>
          </li>
        ))}
      </ul>

      <Reveal delay={200} className="mt-10 flex flex-col gap-3 sm:flex-row">
        <Button asChild variant="cta" size="xl">
          <a href="#simulacao">Solicitar simulação</a>
        </Button>
        <Button asChild variant="onDark" size="xl">
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
            <MessageCircle aria-hidden="true" />
            Falar no WhatsApp
          </a>
        </Button>
      </Reveal>
    </Container>
  </section>
);

export default Contact;
