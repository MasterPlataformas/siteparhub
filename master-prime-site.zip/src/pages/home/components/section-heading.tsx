import { cn } from "@/lib/utils";
import Reveal from "./reveal";

type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  tone?: "light" | "dark";
  className?: string;
};

const SectionHeading = ({
  eyebrow,
  title,
  description,
  align = "left",
  tone = "dark",
  className,
}: SectionHeadingProps) => (
  <Reveal
    className={cn(
      "flex flex-col gap-4",
      align === "center" && "items-center text-center",
      className,
    )}
  >
    <span
      className={cn(
        "eyebrow",
        tone === "dark" ? "text-brand-amber-ink" : "text-brand-amber",
      )}
    >
      {eyebrow}
    </span>
    <h2
      className={cn(
        "text-h2 max-w-[24ch]",
        tone === "dark" ? "text-foreground" : "text-surface-foreground",
      )}
    >
      {title}
    </h2>
    {description ? (
      <p
        className={cn(
          "max-w-[62ch] text-base leading-relaxed",
          tone === "dark" ? "text-muted-foreground" : "text-surface-muted",
        )}
      >
        {description}
      </p>
    ) : null}
  </Reveal>
);

export default SectionHeading;
