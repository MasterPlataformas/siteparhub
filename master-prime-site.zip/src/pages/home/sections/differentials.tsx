import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";
import { DIFFERENTIALS } from "../data";
import { cn } from "@/lib/utils";

const Differentials = () => (
  <section id="diferenciais" className="surface-navy relative overflow-hidden py-16 lg:py-24">
    <div
      aria-hidden="true"
      className="pointer-events-none absolute -bottom-40 -left-32 h-[420px] w-[420px] rounded-full bg-gradient-ring opacity-[0.12]"
    />

    <Container className="relative">
      <SectionHeading
        tone="light"
        eyebrow="Diferenciais"
        title="Por que planejar com a Master Prime"
        description="Somos especialistas em consórcio e trabalhamos com transparência: explicamos custos, prazos, assembleias e possibilidades de contemplação antes da contratação."
        align="center"
        className="mx-auto max-w-[760px] items-center text-center"
      />

      <ul className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-0 lg:divide-x lg:divide-surface-foreground/10">
        {DIFFERENTIALS.map((item, index) => (
          <li key={item.title}>
            <Reveal delay={index * 70} className="flex h-full flex-col lg:px-7">
              <span className="flex h-12 w-12 items-center justify-center rounded-full border border-surface-foreground/12 bg-surface-foreground/[0.06]">
                <item.icon className={cn("h-6 w-6", item.iconClass)} aria-hidden="true" />
              </span>
              <h3 className="mt-5 text-h4 text-surface-foreground">{item.title}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-surface-muted">
                {item.description}
              </p>
            </Reveal>
          </li>
        ))}
      </ul>
    </Container>
  </section>
);

export default Differentials;
