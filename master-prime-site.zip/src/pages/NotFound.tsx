import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";

import Logo from "@/components/brand/logo";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();
  const { t } = useTranslation();

  useEffect(() => {
    console.error("404: rota inexistente acessada:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="surface-navy flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
      <Logo tone="light" />
      <p className="font-display text-stat text-surface-foreground">404</p>
      <p className="text-lead text-surface-muted">{t("notFound.title")}</p>
      <Button asChild variant="cta" size="xl">
        <a href="/">{t("notFound.actions.backHome")}</a>
      </Button>
    </div>
  );
};

export default NotFound;
