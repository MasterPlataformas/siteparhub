import { AlertCircle, CheckCircle2, Loader2, MessageCircle, Send } from "lucide-react";
import { useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { MODALITY_VALUES, whatsappLink } from "@/lib/site";
import type { ModalityValue } from "@/lib/site";
import { cn } from "@/lib/utils";

import { VALUE_RANGES } from "../data";

const onlyDigits = (value: string): string => value.replace(/\D/g, "");

/** Máscara progressiva no formato (11) 91234-5678. */
const formatWhatsapp = (value: string): string => {
  const digits = onlyDigits(value).slice(0, 11);
  if (digits.length === 0) return "";
  if (digits.length <= 2) return `(${digits}`;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10)
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
};

const leadSchema = z.object({
  nome: z.string().trim().min(2, "Informe seu nome completo."),
  whatsapp: z.string().refine((value) => {
    const digits = onlyDigits(value);
    return digits.length >= 10 && digits.length <= 11;
  }, "Informe um WhatsApp válido com DDD."),
  email: z
    .string()
    .trim()
    .refine(
      (value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value),
      "Informe um e-mail válido.",
    ),
  modalidade: z
    .string()
    .refine(
      (value) => (MODALITY_VALUES as readonly string[]).includes(value),
      "Escolha uma modalidade.",
    ),
  valor: z.string(),
  mensagem: z.string().trim().max(400, "Use no máximo 400 caracteres."),
  consent: z.boolean().refine((value) => value, "É necessário autorizar o contato para continuar."),
});

type FormValues = z.infer<typeof leadSchema>;

const EMPTY_VALUES: FormValues = {
  nome: "",
  whatsapp: "",
  email: "",
  modalidade: "",
  valor: "",
  mensagem: "",
  consent: false,
};

type LeadFormProps = {
  /** Modalidade escolhida em um card de modalidades, aplicada no select. */
  requestedModality?: ModalityValue | null;
};

type FieldProps = {
  id: string;
  label: string;
  error?: string;
  hint?: string;
  required?: boolean;
  className?: string;
  children: ReactNode;
};

const Field = ({ id, label, error, hint, required, className, children }: FieldProps) => (
  <div className={cn("flex flex-col gap-2", className)}>
    <Label htmlFor={id} className="text-sm font-semibold text-foreground">
      {label}
      {required ? (
        <span className="ml-1 text-destructive" aria-hidden="true">
          *
        </span>
      ) : (
        <span className="ml-1 text-xs font-normal text-muted-foreground">(opcional)</span>
      )}
    </Label>
    {children}
    {error ? (
      <p
        id={`${id}-error`}
        role="alert"
        className="flex items-center gap-1.5 text-xs font-medium text-destructive"
      >
        <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
        {error}
      </p>
    ) : hint ? (
      <p id={`${id}-hint`} className="text-xs text-muted-foreground">
        {hint}
      </p>
    ) : null}
  </div>
);

const LeadForm = ({ requestedModality }: LeadFormProps) => {
  const [values, setValues] = useState<FormValues>(EMPTY_VALUES);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");

  useEffect(() => {
    if (!requestedModality) return;
    setValues((prev) => ({ ...prev, modalidade: requestedModality }));
    setErrors((prev) => {
      if (!("modalidade" in prev)) return prev;
      const next = { ...prev };
      delete next.modalidade;
      return next;
    });
  }, [requestedModality]);

  const update = (field: keyof FormValues, value: string | boolean) => {
    setValues((prev) => ({ ...prev, [field]: value }) as FormValues);
    setErrors((prev) => {
      if (!(field in prev)) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);

    const parsed = leadSchema.safeParse(values);
    if (!parsed.success) {
      const nextErrors: Record<string, string> = {};
      parsed.error.issues.forEach((issue) => {
        const field = issue.path[0];
        if (typeof field === "string" && !nextErrors[field]) {
          nextErrors[field] = issue.message;
        }
      });
      setErrors(nextErrors);
      const firstField = Object.keys(nextErrors)[0];
      if (firstField) {
        document.getElementById(`lead-${firstField}`)?.focus();
      }
      return;
    }

    setErrors({});
    setStatus("submitting");

    const { error } = await supabase.from("master_prime_leads").insert({
      nome: parsed.data.nome,
      whatsapp: parsed.data.whatsapp,
      email: parsed.data.email === "" ? null : parsed.data.email,
      modalidade: parsed.data.modalidade,
      valor: parsed.data.valor === "" ? null : parsed.data.valor,
      mensagem: parsed.data.mensagem === "" ? null : parsed.data.mensagem,
      consent: parsed.data.consent,
    });

    if (error) {
      setStatus("idle");
      setFormError(
        "Não conseguimos enviar agora. Tente novamente em instantes ou fale com a gente no WhatsApp.",
      );
      return;
    }

    setStatus("success");
  };

  if (status === "success") {
    const successMessage = `Olá! Sou ${values.nome} e acabei de enviar uma simulação de consórcio de ${values.modalidade.toLowerCase()} pelo site.`;

    return (
      <div
        role="status"
        className="flex flex-col items-center gap-4 rounded-2xl border border-border bg-card p-8 text-center text-foreground shadow-lg"
      >
        <CheckCircle2 className="h-12 w-12 text-brand-whatsapp" aria-hidden="true" />
        <h3 className="text-h3 text-card-foreground">Recebemos seu pedido!</h3>
        <p className="max-w-[46ch] text-sm leading-relaxed text-muted-foreground">
          Um consultor Master Prime vai analisar o seu perfil e retornar em até 1 dia útil no
          WhatsApp informado.
        </p>
        <div className="mt-2 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <Button asChild variant="whatsapp" size="xl">
            <a href={whatsappLink(successMessage)} target="_blank" rel="noopener noreferrer">
              <MessageCircle aria-hidden="true" />
              Falar no WhatsApp agora
            </a>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="xl"
            onClick={() => {
              setValues(EMPTY_VALUES);
              setStatus("idle");
            }}
          >
            Enviar outra simulação
          </Button>
        </div>
      </div>
    );
  }

  const submitting = status === "submitting";

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-2xl border border-border bg-card p-6 text-foreground shadow-lg lg:p-8"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="lead-nome" label="Nome completo" required error={errors.nome}>
          <Input
            id="lead-nome"
            name="nome"
            autoComplete="name"
            placeholder="Como podemos te chamar?"
            value={values.nome}
            onChange={(event) => update("nome", event.target.value)}
            aria-invalid={Boolean(errors.nome)}
            aria-describedby={errors.nome ? "lead-nome-error" : undefined}
          />
        </Field>

        <Field id="lead-whatsapp" label="WhatsApp" required error={errors.whatsapp}>
          <Input
            id="lead-whatsapp"
            name="whatsapp"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="(11) 91234-5678"
            value={values.whatsapp}
            onChange={(event) => update("whatsapp", formatWhatsapp(event.target.value))}
            aria-invalid={Boolean(errors.whatsapp)}
            aria-describedby={errors.whatsapp ? "lead-whatsapp-error" : undefined}
          />
        </Field>

        <Field id="lead-email" label="E-mail" error={errors.email}>
          <Input
            id="lead-email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="seunome@email.com"
            value={values.email}
            onChange={(event) => update("email", event.target.value)}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "lead-email-error" : undefined}
          />
        </Field>

        <Field id="lead-modalidade" label="Modalidade" required error={errors.modalidade}>
          <Select
            value={values.modalidade}
            onValueChange={(value) => update("modalidade", value)}
          >
            <SelectTrigger
              id="lead-modalidade"
              aria-invalid={Boolean(errors.modalidade)}
              aria-describedby={errors.modalidade ? "lead-modalidade-error" : undefined}
            >
              <SelectValue placeholder="Selecione a modalidade" />
            </SelectTrigger>
            <SelectContent>
              {MODALITY_VALUES.map((modality) => (
                <SelectItem key={modality} value={modality}>
                  {modality}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field
          id="lead-valor"
          label="Valor aproximado do crédito"
          className="sm:col-span-2"
          hint="Ajuda o consultor a montar uma simulação mais próxima do seu objetivo."
        >
          <Select value={values.valor} onValueChange={(value) => update("valor", value)}>
            <SelectTrigger id="lead-valor">
              <SelectValue placeholder="Selecione uma faixa" />
            </SelectTrigger>
            <SelectContent>
              {VALUE_RANGES.map((range) => (
                <SelectItem key={range} value={range}>
                  {range}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </div>

      <div className="mt-5">
        <Field
          id="lead-mensagem"
          label="Conte um pouco mais"
          error={errors.mensagem}
          hint="Ex.: quero um apartamento de 2 quartos na região de São Caetano."
        >
          <Textarea
            id="lead-mensagem"
            name="mensagem"
            rows={4}
            maxLength={400}
            placeholder="Escreva aqui o seu objetivo..."
            value={values.mensagem}
            onChange={(event) => update("mensagem", event.target.value)}
            aria-invalid={Boolean(errors.mensagem)}
            aria-describedby={errors.mensagem ? "lead-mensagem-error" : "lead-mensagem-hint"}
          />
        </Field>
      </div>

      <div className="mt-5 flex items-start gap-3">
        <Checkbox
          id="lead-consent"
          checked={values.consent}
          onCheckedChange={(checked) => update("consent", checked === true)}
          aria-invalid={Boolean(errors.consent)}
          aria-describedby={errors.consent ? "lead-consent-error" : undefined}
          className="mt-0.5 h-5 w-5"
        />
        <div>
          <Label
            htmlFor="lead-consent"
            className="cursor-pointer text-sm font-normal leading-relaxed text-muted-foreground"
          >
            Autorizo o contato da Master Prime e o tratamento dos meus dados conforme a LGPD.
          </Label>
          {errors.consent ? (
            <p
              id="lead-consent-error"
              role="alert"
              className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-destructive"
            >
              <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              {errors.consent}
            </p>
          ) : null}
        </div>
      </div>

      {formError ? (
        <p
          role="alert"
          className="mt-5 flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          {formError}
        </p>
      ) : null}

      <div className="mt-6">
        <Button
          type="submit"
          variant="cta"
          size="xl"
          disabled={submitting}
          aria-busy={submitting}
          className="w-full sm:w-auto"
        >
          {submitting ? (
            <>
              <Loader2 className="animate-spin" aria-hidden="true" />
              Enviando...
            </>
          ) : (
            <>
              Solicitar simulação
              <Send aria-hidden="true" />
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default LeadForm;
