import { ArrowRight, MessageCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/lib/site";
import type { ModalityValue } from "@/lib/site";
import { cn } from "@/lib/utils";

import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";
import { MODALITIES } from "../data";

type ModalitiesProps = {
  onRequestSimulation: (modality: ModalityValue) => void;
};

const Modalities = ({ onRequestSimulation }: ModalitiesProps) => (
  <section id="modalidades" className="bg-background py-16 lg:py-24">
    <Container>
      <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
        <SectionHeading
          eyebrow="Modalidades"
          title="O que você pode conquistar com consórcio"
          description="Escolha o objetivo, defina o valor da carta de crédito e pague em parcelas ao longo do tempo, sem juros de financiamento."
        />
        <Reveal className="shrink-0">
          <Button asChild variant="outline" size="xl">
            <a href="#como-funciona">
              Como funciona
              <ArrowRight aria-hidden="true" />
            </a>
          </Button>
        </Reveal>
      </div>

      <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
        {MODALITIES.map((modality, index) => (
          <li key={modality.value}>
            <Reveal delay={index * 70} className="h-full">
              <div className="flex h-full flex-col rounded-xl border border-border bg-card p-6 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-lg">
                <span
                  className={cn(
                    "flex h-14 w-14 items-center justify-center rounded-lg",
                    modality.badgeClass,
                  )}
                >
                  <modality.icon className="h-6 w-6" aria-hidden="true" />
                </span>

                <h3 className="mt-5 text-h4 text-card-foreground">{modality.title}</h3>
                <p className="mt-2.5 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {modality.description}
                </p>

                <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2">
                  <button
                    type="button"
                    onClick={() => onRequestSimulation(modality.value)}
                    className="group/link inline-flex items-center gap-1.5 rounded-sm text-sm font-semibold text-primary transition-colors hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  >
                    Simular consórcio
                    <ArrowRight
                      className="h-4 w-4 transition-transform duration-200 group-hover/link:translate-x-1"
                      aria-hidden="true"
                    />
                  </button>
                  <a
                    href={whatsappLink(modality.whatsappMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-sm text-sm font-medium text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    aria-label={`Falar no WhatsApp sobre consórcio de ${modality.title}`}
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden="true" />
                    WhatsApp
                  </a>
                </div>
              </div>
            </Reveal>
          </li>
        ))}
      </ul>
    </Container>
  </section>
);

export default Modalities;
