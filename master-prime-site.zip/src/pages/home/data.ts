import { Bike, Building2, Car, HandCoins, MapPin, ShieldCheck, Wrench } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import type { ModalityValue } from "@/lib/site";

export type Modality = {
  value: ModalityValue;
  title: string;
  description: string;
  icon: LucideIcon;
  /** Classes de cor (token de marca) do ícone e do fundo do selo. */
  badgeClass: string;
  whatsappMessage: string;
};

export const MODALITIES: Modality[] = [
  {
    value: "Imóveis",
    title: "Imóveis",
    description:
      "Planeje casa, apartamento, terreno ou sala comercial com uma carta de crédito sob medida.",
    icon: Building2,
    badgeClass: "bg-ink-blue/10 text-ink-blue",
    whatsappMessage: "Olá! Quero uma simulação de consórcio de imóveis.",
  },
  {
    value: "Veículos",
    title: "Veículos",
    description:
      "Conquiste carro novo ou seminovo com previsibilidade e sem os juros do financiamento.",
    icon: Car,
    badgeClass: "bg-ink-amber/10 text-ink-amber",
    whatsappMessage: "Olá! Quero uma simulação de consórcio de veículos.",
  },
  {
    value: "Motos",
    title: "Motos",
    description:
      "Escolha a moto ideal e organize a compra com parcelas que cabem no seu planejamento.",
    icon: Bike,
    badgeClass: "bg-ink-cyan/10 text-ink-cyan",
    whatsappMessage: "Olá! Quero uma simulação de consórcio de motos.",
  },
  {
    value: "Serviços",
    title: "Serviços",
    description:
      "Use o consórcio para viagens, reformas, estudos, eventos e outros projetos pessoais.",
    icon: Wrench,
    badgeClass: "bg-ink-lilac/10 text-ink-lilac",
    whatsappMessage: "Olá! Quero uma simulação de consórcio de serviços.",
  },
];

export const STEPS = [
  {
    title: "Defina seu objetivo",
    description: "Você informa o bem, o serviço e o valor desejado para a carta de crédito.",
  },
  {
    title: "Receba a simulação",
    description: "Um especialista avalia opções de plano, prazo, parcela e estratégia.",
  },
  {
    title: "Planeje os lances",
    description: "Você acompanha as assembleias e define suas oportunidades de contemplação.",
  },
  {
    title: "Use sua carta",
    description: "Na contemplação, a Master Prime orienta a documentação e o uso do crédito.",
  },
];

export type Differential = {
  title: string;
  description: string;
  icon: LucideIcon;
  /** Cor do ícone dentro da faixa escura. */
  iconClass: string;
};

export const DIFFERENTIALS: Differential[] = [
  {
    title: "Segurança",
    description:
      "Operamos sob as normas do Banco Central do Brasil, com o seu patrimônio em ambiente seguro e monitorado.",
    icon: ShieldCheck,
    iconClass: "text-brand-cyan",
  },
  {
    title: "Sem intermediários",
    description:
      "Pagamento direto e seguro: você paga exclusivamente à administradora, sem intermediários ou terceiros.",
    icon: HandCoins,
    iconClass: "text-brand-amber",
  },
  {
    title: "Atendimento consultivo",
    description:
      "Especialistas em consórcio avaliando plano, prazo, parcela e a melhor estratégia para o seu momento.",
    icon: MapPin,
    iconClass: "text-brand-lilac",
  },
  {
    title: "Suporte especializado",
    description:
      "Consultoria completa em todas as etapas, do planejamento personalizado até a conquista da contemplação.",
    icon: Building2,
    iconClass: "text-brand-yellow",
  },
];

export const TRUST_ITEMS = [
  {
    title: "Sem juros bancários",
    description: "Apenas a taxa administrativa da administradora, sem juros de financiamento.",
    icon: HandCoins,
    iconClass: "text-ink-amber",
  },
  {
    title: "Banco Central do Brasil",
    description: "Sistema regulamentado por lei e fiscalizado pelo Banco Central.",
    icon: ShieldCheck,
    iconClass: "text-ink-blue",
  },
  {
    title: "Pagamento à administradora",
    description: "Você paga direto à administradora, sem intermediários ou terceiros.",
    icon: Building2,
    iconClass: "text-ink-lilac",
  },
  {
    title: "Atendimento em todo o Brasil",
    description: "Consultoria especializada, presencial em São Caetano do Sul ou à distância.",
    icon: MapPin,
    iconClass: "text-ink-cyan",
  },
];

export type FaqItem = {
  question: string;
  answer: string;
};

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: "O que é consórcio?",
    answer:
      "É um modelo em que várias pessoas se unem com o mesmo objetivo: adquirir um bem ou contratar um serviço. Em vez de recorrer a um financiamento com juros, os participantes contribuem mensalmente e recebem uma carta de crédito para realizar a compra.",
  },
  {
    question: "Como funciona o consórcio para imóveis?",
    answer:
      "É uma alternativa planejada para comprar imóveis novos ou usados. Você define o valor do crédito e paga em parcelas ao longo do tempo, sem entrada e sem juros, apenas com a taxa administrativa.",
  },
  {
    question: "Como funciona o consórcio para veículos e motos?",
    answer:
      "A lógica é a mesma: você participa de um grupo e contribui mensalmente para adquirir carro ou moto, sem juros de financiamento e com condições mais acessíveis.",
  },
  {
    question: "O que é o consórcio para serviços?",
    answer:
      "Essa modalidade permite realizar diversos objetivos, como viagens, eventos, estudos, reformas ou procedimentos, com grande flexibilidade de uso do crédito.",
  },
  {
    question: "Posso usar o consórcio para construir ou reformar?",
    answer:
      "Sim. O crédito pode ser destinado a obras ou reformas em um imóvel próprio, desde que esteja regularizado e no nome do participante.",
  },
  {
    question: "É possível quitar um financiamento com consórcio?",
    answer:
      "Sim. Muitas pessoas utilizam o crédito para liquidar financiamentos e substituir juros elevados por uma taxa administrativa mais baixa.",
  },
  {
    question: "Qual é a função da administradora?",
    answer:
      "Ela organiza os grupos, gerencia os pagamentos, realiza as contemplações e garante que tudo siga as regras, sempre com a supervisão do Banco Central do Brasil.",
  },
  {
    question: "Como funciona o grupo de consórcio?",
    answer:
      "Os participantes são organizados em grupos. Todos contribuem mensalmente, formando um fundo comum que é usado para liberar os créditos ao longo do tempo.",
  },
  {
    question: "Como são calculadas as parcelas?",
    answer:
      "As parcelas variam conforme o valor do crédito e o prazo escolhido, e podem sofrer ajustes periódicos para manter o poder de compra.",
  },
  {
    question: "Quando e como recebo o crédito?",
    answer:
      "A contemplação pode acontecer por sorteio ou por lance. Não existe prazo fixo, porque depende da dinâmica do grupo. Os sorteios ocorrem mensalmente, geralmente com base na Loteria Federal, e participam os consorciados com as parcelas em dia.",
  },
  {
    question: "O que são lances e como funcionam?",
    answer:
      "Lances são antecipações de pagamento que aumentam as suas chances de contemplação. Podem ser fixos ou livres, conforme a estratégia definida com o seu consultor.",
  },
  {
    question: "Posso usar o FGTS no consórcio?",
    answer:
      "Sim. O FGTS pode ser utilizado para lances, amortização ou quitação, conforme as regras aplicáveis a cada caso.",
  },
  {
    question: "Posso vender minha cota?",
    answer:
      "Sim. A cota pode ser transferida para outra pessoa, inclusive com possibilidade de ganho caso já esteja contemplada.",
  },
  {
    question: "O consórcio é seguro?",
    answer:
      "Sim. O sistema é regulamentado por lei e supervisionado pelo Banco Central do Brasil. A Master Prime atua com transparência, explicando custos, prazos, assembleias e possibilidades de contemplação antes de qualquer contratação.",
  },
];

export const HERO_PHOTO = {
  src: "https://cdn.enter.pro/resources/uid_100625452/466182a4-98f3-41.jpeg",
  alt: "Salão de atendimento da Master Prime, com pé-direito de concreto aparente, sofá curvo azul-marinho e jardim interno",
  width: 900,
  height: 1600,
};

export type GalleryPhoto = {
  src: string;
  alt: string;
  caption: string;
  width: number;
  height: number;
};

export const GALLERY: GalleryPhoto[] = [
  {
    src: "https://cdn.enter.pro/resources/uid_100625452/3cdaa107-b41c-4d.jpeg",
    alt: "Símbolo da Master Prime aplicado em parede de madeira, cercado por plantas",
    caption: "A marca na recepção",
    width: 720,
    height: 1280,
  },
  {
    src: "https://cdn.enter.pro/resources/uid_100625452/9377f60b-1e85-45.jpeg",
    alt: "Letreiro Master Prime na parede, com poltronas e cliente em atendimento",
    caption: "Sala de espera",
    width: 720,
    height: 1280,
  },
  {
    src: "https://cdn.enter.pro/resources/uid_100625452/c8760664-40b5-4d.jpeg",
    alt: "Vista aérea de condomínio residencial e parque arborizado na cidade",
    caption: "O que o crédito conquista",
    width: 720,
    height: 1280,
  },
];

export const VALUE_RANGES = [
  "Até R$ 50 mil",
  "De R$ 50 mil a R$ 150 mil",
  "De R$ 150 mil a R$ 300 mil",
  "De R$ 300 mil a R$ 500 mil",
  "Acima de R$ 500 mil",
  "Prefiro informar depois",
];
