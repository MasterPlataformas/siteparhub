import type { Config } from "tailwindcss";
import tailwindcssAnimate from "tailwindcss-animate";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border) / <alpha-value>)',
				input: 'hsl(var(--input) / <alpha-value>)',
				ring: 'hsl(var(--ring) / <alpha-value>)',
				background: 'hsl(var(--background) / <alpha-value>)',
				foreground: 'hsl(var(--foreground) / <alpha-value>)',
				primary: {
					DEFAULT: 'hsl(var(--primary) / <alpha-value>)',
					foreground: 'hsl(var(--primary-foreground) / <alpha-value>)'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary) / <alpha-value>)',
					foreground: 'hsl(var(--secondary-foreground) / <alpha-value>)'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive) / <alpha-value>)',
					foreground: 'hsl(var(--destructive-foreground) / <alpha-value>)'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted) / <alpha-value>)',
					foreground: 'hsl(var(--muted-foreground) / <alpha-value>)'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent) / <alpha-value>)',
					foreground: 'hsl(var(--accent-foreground) / <alpha-value>)'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover) / <alpha-value>)',
					foreground: 'hsl(var(--popover-foreground) / <alpha-value>)'
				},
				card: {
					DEFAULT: 'hsl(var(--card) / <alpha-value>)',
					foreground: 'hsl(var(--card-foreground) / <alpha-value>)'
				},
				/* Segmentos do anel do logo Master Prime (decorativos) */
				brand: {
					yellow: 'hsl(var(--brand-yellow) / <alpha-value>)',
					cyan: 'hsl(var(--brand-cyan) / <alpha-value>)',
					blue: 'hsl(var(--brand-blue) / <alpha-value>)',
					lilac: 'hsl(var(--brand-lilac) / <alpha-value>)',
					amber: 'hsl(var(--brand-amber) / <alpha-value>)',
					palm: 'hsl(var(--brand-palm) / <alpha-value>)',
					concrete: 'hsl(var(--brand-concrete) / <alpha-value>)',
					whatsapp: 'hsl(var(--brand-whatsapp) / <alpha-value>)',
					'whatsapp-foreground': 'hsl(var(--brand-whatsapp-foreground) / <alpha-value>)'
				},
				/* Versões escuras para ícone/texto sobre fundo claro */
				ink: {
					blue: 'hsl(var(--brand-blue-ink) / <alpha-value>)',
					cyan: 'hsl(var(--brand-cyan-ink) / <alpha-value>)',
					lilac: 'hsl(var(--brand-lilac-ink) / <alpha-value>)',
					amber: 'hsl(var(--brand-amber-ink) / <alpha-value>)'
				},
				/* Superfícies escuras da marca */
				surface: {
					DEFAULT: 'hsl(var(--surface-navy-800) / <alpha-value>)',
					'700': 'hsl(var(--surface-navy-700) / <alpha-value>)',
					'800': 'hsl(var(--surface-navy-800) / <alpha-value>)',
					'900': 'hsl(var(--surface-navy-900) / <alpha-value>)',
					foreground: 'hsl(var(--surface-navy-foreground) / <alpha-value>)',
					muted: 'hsl(var(--surface-navy-muted) / <alpha-value>)'
				}
			},
			fontFamily: {
				sans: ['Inter', 'system-ui', 'sans-serif'],
				display: ['"Plus Jakarta Sans"', 'Inter', 'system-ui', 'sans-serif']
			},
			fontSize: {
				hero: ['clamp(2.25rem, 6.2vw, 4.25rem)', { lineHeight: '1.06', letterSpacing: '-0.03em', fontWeight: '800' }],
				h2: ['clamp(1.75rem, 3.4vw, 2.5rem)', { lineHeight: '1.15', letterSpacing: '-0.02em', fontWeight: '700' }],
				h3: ['clamp(1.375rem, 2.2vw, 1.75rem)', { lineHeight: '1.25', letterSpacing: '-0.015em', fontWeight: '700' }],
				h4: ['1.25rem', { lineHeight: '1.3', letterSpacing: '-0.01em', fontWeight: '600' }],
				lead: ['clamp(1.0625rem, 1.4vw, 1.25rem)', { lineHeight: '1.65' }],
				stat: ['clamp(2rem, 4vw, 3rem)', { lineHeight: '1', letterSpacing: '-0.02em', fontWeight: '800' }],
				eyebrow: ['0.75rem', { lineHeight: '1.2', letterSpacing: '0.14em', fontWeight: '700' }]
			},
			boxShadow: {
				sm: '0 1px 2px hsl(200 55% 13% / 0.06), 0 2px 6px hsl(200 55% 13% / 0.05)',
				md: '0 4px 12px hsl(200 55% 13% / 0.08), 0 2px 4px hsl(200 55% 13% / 0.05)',
				lg: '0 12px 28px hsl(200 55% 13% / 0.12), 0 4px 8px hsl(200 55% 13% / 0.06)',
				xl: '0 24px 56px hsl(200 55% 13% / 0.16)',
				fab: '0 8px 20px hsl(171 81% 23% / 0.38), 0 2px 6px hsl(200 55% 13% / 0.16)'
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 4px)',
				sm: 'calc(var(--radius) - 8px)',
				xl: '20px',
				'2xl': '28px',
				'3xl': '36px'
			},
			backgroundImage: {
				'gradient-hero': 'var(--gradient-hero)',
				'gradient-navy': 'var(--gradient-navy-fade)',
				'gradient-cta': 'var(--gradient-cta)',
				'gradient-warm': 'var(--gradient-warm)',
				'gradient-ring': 'var(--gradient-ring)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-rise': {
					from: {
						opacity: '0',
						transform: 'translateY(14px)'
					},
					to: {
						opacity: '1',
						transform: 'none'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-rise': 'fade-rise 560ms cubic-bezier(0.05, 0.7, 0.1, 1) both'
			}
		}
	},
	plugins: [tailwindcssAnimate],
} satisfies Config;
