import Logo from "@/components/brand/logo";
import { CONTACT, whatsappLink } from "@/lib/site";

import Container from "./container";
import { MODALITIES } from "../data";

const SiteFooter = () => (
  <footer className="bg-surface-900 pb-16 pt-14 lg:pb-20">
    <Container>
      <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1.2fr] lg:gap-12">
        <div>
          <Logo tone="light" />
          <p className="mt-5 max-w-[34ch] text-sm leading-relaxed text-surface-muted">
            Especialistas em realizar sonhos. Consórcio planejado com atendimento consultivo para
            imóveis, veículos, motos e serviços.
          </p>
        </div>

        <div>
          <p className="eyebrow text-surface-muted">Modalidades</p>
          <ul className="mt-5 flex flex-col gap-3">
            {MODALITIES.map((modality) => (
              <li key={modality.value}>
                <a
                  href="#modalidades"
                  className="text-sm text-surface-muted transition-colors hover:text-surface-foreground"
                >
                  Consórcio de {modality.title.toLowerCase()}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="eyebrow text-surface-muted">Atendimento</p>
          <ul className="mt-5 flex flex-col gap-4 text-sm">
            <li className="text-surface-muted">
              <span className="block text-surface-foreground">{CONTACT.addressLine}</span>
              {CONTACT.city}
            </li>
            <li>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="text-surface-foreground transition-colors hover:text-brand-amber"
              >
                WhatsApp {CONTACT.whatsappDisplay}
              </a>
            </li>
            <li>
              <a
                href={`tel:${CONTACT.phoneHref}`}
                className="text-surface-foreground transition-colors hover:text-brand-amber"
              >
                SAC {CONTACT.phoneDisplay}
              </a>
            </li>
            <li>
              <a
                href={CONTACT.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-surface-foreground transition-colors hover:text-brand-amber"
              >
                {CONTACT.instagramHandle}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-12 border-t border-surface-foreground/10 pt-6">
        <p className="text-xs leading-relaxed text-surface-muted">
          Consórcio é regulamentado e fiscalizado pelo Banco Central do Brasil. A contemplação
          depende de sorteio ou lance e não há garantia de prazo. Leia o contrato de adesão e o
          regulamento do grupo antes de contratar.
        </p>
        <p className="mt-4 text-xs text-surface-muted">
          © {new Date().getFullYear()} Master Prime Consórcios · CNPJ {CONTACT.cnpj}
        </p>
      </div>
    </Container>
  </footer>
);

export default SiteFooter;
