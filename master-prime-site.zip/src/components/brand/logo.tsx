import { cn } from "@/lib/utils";

type RingSegment = {
  color: string;
  from: number;
  to: number;
};

/** Anel do logo: 4 arcos na cor de cada segmento, com a abertura à esquerda. */
const RING_SEGMENTS: RingSegment[] = [
  { color: "hsl(var(--brand-yellow))", from: 205, to: 285 },
  { color: "hsl(var(--brand-cyan))", from: 293, to: 4 },
  { color: "hsl(var(--brand-blue))", from: 12, to: 96 },
  { color: "hsl(var(--brand-lilac))", from: 104, to: 197 },
];

const CENTER = 32;
const RADIUS = 23;

function polarPoint(angle: number): [number, number] {
  const radians = ((angle - 90) * Math.PI) / 180;
  return [
    Number((CENTER + RADIUS * Math.cos(radians)).toFixed(2)),
    Number((CENTER + RADIUS * Math.sin(radians)).toFixed(2)),
  ];
}

function arcPath(from: number, to: number): string {
  const [startX, startY] = polarPoint(from);
  const [endX, endY] = polarPoint(to);
  const largeArc = (to - from + 360) % 360 > 180 ? 1 : 0;
  return `M ${startX} ${startY} A ${RADIUS} ${RADIUS} 0 ${largeArc} 1 ${endX} ${endY}`;
}

type LogoProps = {
  /** `light` para uso sobre fundo escuro, `dark` para uso sobre fundo claro. */
  tone?: "light" | "dark";
  withWordmark?: boolean;
  className?: string;
};

const Logo = ({ tone = "dark", withWordmark = true, className }: LogoProps) => (
  <span className={cn("inline-flex items-center gap-2.5", className)}>
    <svg
      viewBox="0 0 64 64"
      aria-hidden="true"
      className="h-9 w-9 shrink-0 lg:h-10 lg:w-10"
      fill="none"
    >
      {RING_SEGMENTS.map((segment) => (
        <path
          key={segment.color}
          d={arcPath(segment.from, segment.to)}
          stroke={segment.color}
          strokeWidth={5}
          strokeLinecap="butt"
        />
      ))}
      <text
        x={CENTER}
        y={CENTER + 1.5}
        textAnchor="middle"
        dominantBaseline="middle"
        fontFamily='"Plus Jakarta Sans", Inter, system-ui, sans-serif'
        fontWeight={800}
        fontSize={26}
        letterSpacing="-1"
        fill={tone === "light" ? "hsl(var(--surface-navy-foreground))" : "hsl(var(--primary))"}
      >
        M
      </text>
    </svg>
    {withWordmark ? (
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.0625rem] font-extrabold tracking-tight lg:text-lg",
            tone === "light" ? "text-surface-foreground" : "text-foreground",
          )}
        >
          Master Prime
        </span>
        <span
          className={cn(
            "font-display text-[0.5625rem] font-semibold uppercase tracking-[0.28em]",
            tone === "light" ? "text-surface-muted" : "text-muted-foreground",
          )}
        >
          Consórcios
        </span>
      </span>
    ) : null}
  </span>
);

export default Logo;
