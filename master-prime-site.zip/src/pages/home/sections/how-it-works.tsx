import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";
import { STEPS } from "../data";
import { cn } from "@/lib/utils";

const HowItWorks = () => (
  <section id="como-funciona" className="bg-gradient-warm py-16 lg:py-24">
    <Container size="narrow">
      <SectionHeading
        eyebrow="Como funciona"
        title="Do objetivo à contemplação, com apoio em cada etapa"
        description="O consórcio é simples quando alguém explica o caminho: você define o objetivo, o especialista monta a simulação e nós acompanhamos você até o uso da carta de crédito."
        align="center"
        className="mx-auto items-center text-center"
      />

      <div className="relative mt-14">
        <div
          aria-hidden="true"
          className="absolute inset-x-0 top-6 hidden h-0.5 bg-gradient-to-r from-primary/30 via-accent/50 to-accent/60 lg:block"
        />
        <ol className="grid gap-10 lg:grid-cols-4 lg:gap-6">
          {STEPS.map((step, index) => (
            <li key={step.title}>
              <Reveal delay={index * 80} className="flex gap-5 lg:block">
                <span
                  className={cn(
                    "relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-border bg-card font-display text-h4 font-bold text-primary shadow-sm",
                    index < STEPS.length - 1 &&
                      "before:absolute before:left-6 before:top-12 before:h-[calc(100%-0.5rem)] before:w-px before:content-[''] before:bg-border lg:before:hidden",
                  )}
                >
                  {index + 1}
                </span>
                <div className="lg:mt-6">
                  <h3 className="text-h4 text-foreground">{step.title}</h3>
                  <p className="mt-2 max-w-[36ch] text-sm leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </Container>
  </section>
);

export default HowItWorks;
