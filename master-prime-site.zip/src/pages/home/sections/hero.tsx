import { MapPin, MessageCircle, ShieldCheck, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/lib/site";

import Container from "../components/container";
import { HERO_PHOTO, MODALITIES } from "../data";

const HERO_FACTS = [
  {
    icon: ShieldCheck,
    title: "Banco Central do Brasil",
    description: "Sistema regulamentado e fiscalizado",
  },
  {
    icon: MapPin,
    title: "Atendimento em todo o Brasil",
    description: "Consultoria especializada em cada etapa",
  },
];

const Hero = () => (
  <section
    id="inicio"
    className="relative overflow-hidden bg-gradient-hero pb-24 pt-28 lg:pb-32 lg:pt-36"
  >
    <div
      aria-hidden="true"
      className="pointer-events-none absolute -right-28 -top-28 h-[420px] w-[420px] rounded-full bg-gradient-ring opacity-[0.16] lg:h-[560px] lg:w-[560px]"
    />
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_55%_at_28%_0%,hsl(39_73%_55%/0.22),transparent_62%)]"
    />

    <Container className="relative">
      <div className="grid gap-16 lg:grid-cols-12 lg:items-center lg:gap-8">
        <div className="animate-fade-rise lg:col-span-7">
          <span className="eyebrow inline-flex items-center gap-2 rounded-full border border-brand-amber/30 bg-brand-amber/10 px-3.5 py-1.5 text-brand-amber">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            Especialistas em consórcio
          </span>

          <h1 className="mt-6 max-w-[16ch] text-hero text-surface-foreground">
            Conquiste seu imóvel, veículo ou projeto com a Master Prime.
          </h1>

          <p className="mt-6 max-w-[54ch] text-lead text-surface-muted">
            Consórcio planejado com atendimento consultivo: montamos a simulação do plano ideal
            para o seu momento, com parcelas que cabem no seu orçamento e sem juros bancários.
          </p>

          <ul className="mt-8 flex flex-wrap gap-2.5">
            {MODALITIES.map((modality) => (
              <li key={modality.value}>
                <a
                  href="#modalidades"
                  className="inline-flex items-center gap-2 rounded-full border border-surface-foreground/20 bg-surface-foreground/[0.08] px-4 py-2 text-sm text-surface-foreground transition-colors hover:border-surface-foreground/40 hover:bg-surface-foreground/[0.14]"
                >
                  <modality.icon className="h-4 w-4" aria-hidden="true" />
                  {modality.title}
                </a>
              </li>
            ))}
          </ul>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button asChild variant="cta" size="xl">
              <a href="#simulacao">Solicitar simulação</a>
            </Button>
            <Button asChild variant="onDark" size="xl">
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
                <MessageCircle aria-hidden="true" />
                Falar no WhatsApp
              </a>
            </Button>
          </div>

          <p className="mt-7 flex items-start gap-2 text-xs text-surface-muted">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" aria-hidden="true" />
            Regulamentado e fiscalizado pelo Banco Central do Brasil. A contemplação depende de
            sorteio ou lance e não há garantia de prazo.
          </p>
        </div>

        <div className="lg:col-span-5">
          <div className="relative mx-auto max-w-[420px] lg:ml-auto">
            <div className="overflow-hidden rounded-3xl border border-surface-foreground/10 shadow-xl">
              <img
                src={HERO_PHOTO.src}
                alt={HERO_PHOTO.alt}
                width={HERO_PHOTO.width}
                height={HERO_PHOTO.height}
                className="aspect-[4/5] h-full w-full object-cover"
              />
            </div>

            <div
              aria-hidden="true"
              className="absolute -right-5 -top-5 h-20 w-20 rounded-full bg-gradient-ring p-[6px] shadow-md lg:h-24 lg:w-24"
            >
              <div className="h-full w-full rounded-full bg-surface-900" />
            </div>

            <div className="absolute -bottom-8 left-4 right-4 rounded-xl border border-border bg-card p-4 shadow-lg lg:-left-6 lg:right-6">
              <ul className="flex flex-col gap-3">
                {HERO_FACTS.map((fact) => (
                  <li key={fact.title} className="flex items-start gap-3">
                    <fact.icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                    <div>
                      <p className="font-display text-sm font-bold text-card-foreground">
                        {fact.title}
                      </p>
                      <p className="text-xs text-muted-foreground">{fact.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Container>
  </section>
);

export default Hero;
