import { useEffect, useState } from "react";

const SECTION_IDS = [
  "inicio",
  "modalidades",
  "como-funciona",
  "nosso-espaco",
  "faq",
  "contato",
];

/** Id da seção que está cruzando o centro da viewport (navegação ativa). */
export function useActiveSection(): string {
  const [active, setActive] = useState<string>(SECTION_IDS[0]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (visible?.target.id) {
          setActive(visible.target.id);
        }
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 },
    );

    SECTION_IDS.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });

    return () => observer.disconnect();
  }, []);

  return active;
}
