import { HandCoins, ShieldCheck, Wallet } from "lucide-react";

import type { ModalityValue } from "@/lib/site";

import Container from "../components/container";
import LeadForm from "../components/lead-form";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";

const SIMULATION_POINTS = [
  {
    icon: HandCoins,
    title: "Sem juros bancários",
    description: "Você paga apenas a taxa administrativa da administradora.",
  },
  {
    icon: ShieldCheck,
    title: "Banco Central do Brasil",
    description: "Sistema regulamentado por lei e fiscalizado.",
  },
  {
    icon: Wallet,
    title: "Pagamento direto à administradora",
    description: "Sem intermediários ou terceiros no meio do caminho.",
  },
];

type SimulationProps = {
  requestedModality: ModalityValue | null;
};

const Simulation = ({ requestedModality }: SimulationProps) => (
  <section id="simulacao" className="surface-navy py-16 lg:py-24">
    <Container>
      <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <SectionHeading
            tone="light"
            eyebrow="Simulação"
            title="Simule agora e receba uma proposta personalizada"
            description="Preencha os dados e um especialista da Master Prime retorna com as opções de plano, prazo e parcela que combinam com o seu objetivo."
          />

          <Reveal delay={120}>
            <ul className="mt-9 flex flex-col gap-5">
              {SIMULATION_POINTS.map((point) => (
                <li key={point.title} className="flex gap-3.5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-surface-foreground/12 bg-surface-foreground/[0.06]">
                    <point.icon className="h-5 w-5 text-brand-amber" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="font-display text-sm font-bold text-surface-foreground">
                      {point.title}
                    </p>
                    <p className="mt-0.5 text-sm text-surface-muted">{point.description}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        <div className="lg:col-span-7">
          <Reveal delay={80}>
            <LeadForm requestedModality={requestedModality} />
          </Reveal>
        </div>
      </div>
    </Container>
  </section>
);

export default Simulation;
