import { ArrowUpRight, Instagram } from "lucide-react";

import { CONTACT } from "@/lib/site";
import { cn } from "@/lib/utils";

import Container from "../components/container";
import Reveal from "../components/reveal";
import SectionHeading from "../components/section-heading";
import { GALLERY } from "../data";

const Gallery = () => (
  <section id="nosso-espaco" className="bg-background py-16 lg:py-24">
    <Container>
      <SectionHeading
        eyebrow="Nosso espaço"
        title="Um escritório feito para receber bem"
        description="Atendemos em São Caetano do Sul, nas Salas 720 e 721, e acompanhamos clientes de todo o Brasil. Venha tomar um café e conversar sobre o seu objetivo."
      />

      <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:items-start lg:gap-5">
        {GALLERY.map((photo, index) => (
          <Reveal key={photo.src} delay={index * 70} className={cn(index % 2 === 1 && "lg:mt-10")}>
            <figure className="group h-full overflow-hidden rounded-xl border border-border bg-card shadow-sm">
              <img
                src={photo.src}
                alt={photo.alt}
                width={photo.width}
                height={photo.height}
                loading="lazy"
                decoding="async"
                className="aspect-[3/4] w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
              />
              <figcaption className="px-4 py-3 text-xs font-medium text-muted-foreground">
                {photo.caption}
              </figcaption>
            </figure>
          </Reveal>
        ))}

        <Reveal delay={210} className="lg:mt-10">
          <a
            href={CONTACT.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex h-full flex-col justify-between gap-8 rounded-xl bg-surface-800 p-6 shadow-sm transition-transform duration-200 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            aria-label={`Abrir o Instagram ${CONTACT.instagramHandle} (abre em nova aba)`}
          >
            <Instagram className="h-7 w-7 text-brand-amber" aria-hidden="true" />
            <div>
              <p className="font-display text-h4 text-surface-foreground">
                Acompanhe nas redes
              </p>
              <p className="mt-2 text-sm leading-relaxed text-surface-muted">
                Conquistas, bastidores e o dia a dia de quem confia na Master Prime.
              </p>
              <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-amber">
                {CONTACT.instagramHandle}
                <ArrowUpRight
                  className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  aria-hidden="true"
                />
              </span>
            </div>
          </a>
        </Reveal>
      </div>
    </Container>
  </section>
);

export default Gallery;
