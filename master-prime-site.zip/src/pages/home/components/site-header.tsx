import { Menu, MessageCircle } from "lucide-react";
import { useState } from "react";

import Logo from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useActiveSection } from "@/hooks/use-active-section";
import { useScrolled } from "@/hooks/use-scrolled";
import { CONTACT, NAV_LINKS, whatsappLink } from "@/lib/site";
import { cn } from "@/lib/utils";

import Container from "./container";

const MOBILE_EXTRA_LINKS = [{ id: "contato", label: "Contato" }];

const SiteHeader = () => {
  const scrolled = useScrolled(24);
  const activeSection = useActiveSection();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-200",
        scrolled
          ? "border-b border-border bg-background/90 shadow-sm backdrop-blur-md"
          : "border-b border-transparent",
      )}
    >
      <Container className="flex h-16 items-center justify-between gap-4 lg:h-20">
        <a
          href="#inicio"
          className="rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          aria-label="Master Prime Consórcios, ir para o início"
        >
          <Logo tone={scrolled ? "dark" : "light"} />
        </a>

        <nav aria-label="Navegação principal" className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.id}
                href={`#${link.id}`}
                aria-current={isActive ? "true" : undefined}
                className={cn(
                  "group relative py-1 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                  scrolled
                    ? "text-foreground hover:text-primary"
                    : "text-surface-foreground/85 hover:text-surface-foreground",
                  isActive && (scrolled ? "text-primary" : "text-surface-foreground"),
                )}
              >
                {link.label}
                <span
                  className={cn(
                    "absolute inset-x-0 -bottom-0.5 h-0.5 origin-left rounded-full bg-accent transition-transform duration-200",
                    isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                  )}
                />
              </a>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Button asChild variant={scrolled ? "outline" : "onDark"} size="xl">
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
              <MessageCircle aria-hidden="true" />
              WhatsApp
            </a>
          </Button>
          <Button asChild variant="cta" size="xl">
            <a href="#simulacao">Solicitar simulação</a>
          </Button>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <Button
            asChild
            variant={scrolled ? "outline" : "onDark"}
            size="icon"
            className="h-11 w-11 rounded-full"
          >
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Falar no WhatsApp ${CONTACT.whatsappDisplay}`}
            >
              <MessageCircle aria-hidden="true" />
            </a>
          </Button>

          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant={scrolled ? "outline" : "onDark"}
                size="icon"
                className="h-11 w-11 rounded-full"
                aria-label="Abrir menu de navegação"
              >
                <Menu aria-hidden="true" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full border-none bg-surface-900 p-6">
              <SheetHeader className="text-left">
                <SheetTitle className="sr-only">Menu de navegação</SheetTitle>
                <Logo tone="light" />
              </SheetHeader>

              <nav aria-label="Navegação principal (mobile)" className="mt-10 flex flex-col">
                {[...NAV_LINKS, ...MOBILE_EXTRA_LINKS].map((link) => (
                  <a
                    key={link.id}
                    href={`#${link.id}`}
                    onClick={() => setMenuOpen(false)}
                    className="border-b border-surface-foreground/10 py-4 font-display text-h3 text-surface-foreground transition-colors hover:text-brand-amber"
                  >
                    {link.label}
                  </a>
                ))}
              </nav>

              <div className="mt-8 flex flex-col gap-3">
                <Button asChild variant="cta" size="xl">
                  <a href="#simulacao" onClick={() => setMenuOpen(false)}>
                    Solicitar simulação
                  </a>
                </Button>
                <Button asChild variant="whatsapp" size="xl">
                  <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
                    <MessageCircle aria-hidden="true" />
                    Falar no WhatsApp
                  </a>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </Container>
    </header>
  );
};

export default SiteHeader;
