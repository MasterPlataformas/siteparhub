import { useState } from "react";

import SiteFooter from "./components/site-footer";
import SiteHeader from "./components/site-header";
import WhatsAppFab from "./components/whatsapp-fab";
import Contact from "./sections/contact";
import Differentials from "./sections/differentials";
import Faq from "./sections/faq";
import Gallery from "./sections/gallery";
import Hero from "./sections/hero";
import HowItWorks from "./sections/how-it-works";
import Modalities from "./sections/modalities";
import Simulation from "./sections/simulation";
import TrustStrip from "./sections/trust-strip";
import { scrollToSection } from "@/lib/site";
import type { ModalityValue } from "@/lib/site";

const Home = () => {
  const [requestedModality, setRequestedModality] = useState<ModalityValue | null>(null);

  const handleRequestSimulation = (modality: ModalityValue) => {
    setRequestedModality(modality);
    scrollToSection("simulacao");
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <SiteHeader />

      <main className="flex-1">
        <Hero />
        <TrustStrip />
        <Modalities onRequestSimulation={handleRequestSimulation} />
        <HowItWorks />
        <Differentials />
        <Simulation requestedModality={requestedModality} />
        <Gallery />
        <Faq />
        <Contact />
      </main>

      <SiteFooter />
      <WhatsAppFab />
    </div>
  );
};

export default Home;
