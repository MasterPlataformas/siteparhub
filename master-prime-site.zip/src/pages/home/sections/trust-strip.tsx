import { cn } from "@/lib/utils";

import Container from "../components/container";
import Reveal from "../components/reveal";
import { TRUST_ITEMS } from "../data";

const TrustStrip = () => (
  <section aria-label="Por que escolher a Master Prime" className="border-b border-border bg-card">
    <Container>
      <ul className="grid gap-7 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8 lg:py-14">
        {TRUST_ITEMS.map((item, index) => (
          <li key={item.title}>
            <Reveal delay={index * 70} className="flex h-full gap-3.5">
              <span
                className={cn(
                  "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-muted",
                  item.iconClass,
                )}
              >
                <item.icon className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-display text-sm font-bold text-foreground">{item.title}</p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </div>
            </Reveal>
          </li>
        ))}
      </ul>
    </Container>
  </section>
);

export default TrustStrip;
