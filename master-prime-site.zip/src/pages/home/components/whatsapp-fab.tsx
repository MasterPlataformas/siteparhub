import { MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";

import { CONTACT, whatsappLink } from "@/lib/site";
import { cn } from "@/lib/utils";

/** Atalho sempre disponível para o WhatsApp, escondido enquanto o formulário está em tela. */
const WhatsAppFab = () => {
  const [entered, setEntered] = useState(false);
  const [overForm, setOverForm] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setEntered(true), 600);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const section = document.getElementById("simulacao");
    if (!section) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => setOverForm(entry.isIntersecting));
      },
      { threshold: 0.4 },
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Falar no WhatsApp ${CONTACT.whatsappDisplay}`}
      className={cn(
        "group fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] right-4 z-50 flex h-14 items-center rounded-full bg-brand-whatsapp pl-4 pr-4 text-brand-whatsapp-foreground shadow-fab transition-all duration-300 ease-out lg:right-8",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        entered && !overForm
          ? "translate-y-0 opacity-100"
          : "pointer-events-none translate-y-3 opacity-0",
      )}
    >
      <MessageCircle aria-hidden="true" className="h-6 w-6 shrink-0" />
      <span className="hidden w-0 overflow-hidden whitespace-nowrap text-sm font-semibold transition-all duration-300 group-hover:w-[9.5rem] lg:inline-block">
        Falar no WhatsApp
      </span>
    </a>
  );
};

export default WhatsAppFab;
